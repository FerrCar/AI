
require('dotenv').config();
const express = require('express');
const fetch = require('node-fetch');
const path = require('path');

const app = express();
app.use(express.json());
app.use(express.static('public'));

app.post('/api/chat', async (req, res) => {
  const userMessage = req.body.message;

  try {
    const openaiRes = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [{ role: 'user', content: userMessage }]
      })
    });

    if (!openaiRes.ok) {
      const error = await openaiRes.json();
      return res.status(500).json({ error: error.error.message });
    }

    const data = await openaiRes.json();
    const botReply = data.choices?.[0]?.message?.content || "Nessuna risposta 😕";
    res.json({ reply: botReply });

  } catch (err) {
    res.status(500).json({ error: 'Errore di rete o server.' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server attivo su http://localhost:${PORT}`));
